import { useState, useEffect, useRef } from 'react';
import { X, FileText, Activity, Eye, CheckCircle2, AlertCircle, AlertTriangle, User, MapPin, CreditCard, Send, Radio, Mail, DollarSign, Undo2, PenTool, TrendingUp, Navigation, Camera, Zap, Download, Sparkles, CheckCircle, XCircle, Smartphone, Wand2, MessageSquare, MessagesSquare, Bold, Italic, List, Type, Paperclip, Underline as UnderlineIcon, AlignLeft, AlignCenter, AlignRight, ListOrdered, Undo, Redo, ChevronDown } from 'lucide-react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Color } from '@tiptap/extension-color';
import { TextStyle } from '@tiptap/extension-text-style';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import type { Infringement, AuditLog } from '../types/database';
import { formatCurrency, formatAppDate } from '../utils/formatters';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';

interface InfringementDrawerProps {
  infringement: Infringement;
  isOpen: boolean;
  onClose: () => void;
  onUpdate?: (updatedInfringement: Infringement) => void;
}

type Tab = 'overview' | 'telematics' | 'communications' | 'financials' | 'documents';

type CommunicationChannel = 'email' | 'sms' | 'whatsapp';

interface CommunicationMessage {
  id: number;
  type: CommunicationChannel;
  text: string;
  date: string;
  sender: string;
}

export function InfringementDrawer({ infringement, isOpen, onClose, onUpdate }: InfringementDrawerProps) {
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSignaturePad, setShowSignaturePad] = useState(false);
  const [isVerified, setIsVerified] = useState(false);

  const [messageHistory, setMessageHistory] = useState<CommunicationMessage[]>([
    { id: 1, type: 'email', text: 'Initial nomination request sent.', date: '24-Feb-2026 10:00 AM', sender: 'System' },
    { id: 2, type: 'sms', text: 'Please check your email regarding infringement FLC002.', date: '24-Feb-2026 10:05 AM', sender: 'Jenny' }
  ]);
  const [messageText, setMessageText] = useState('');
  const [activeChannel, setActiveChannel] = useState<CommunicationChannel>('email');
  const [isTemplateMenuOpen, setIsTemplateMenuOpen] = useState(false);
  const [isColorMenuOpen, setIsColorMenuOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messageHistory]);

  const GMAIL_COLORS = [
    // Grayscale
    '#000000', '#434343', '#666666', '#999999', '#cccccc', '#efefef', '#f3f3f3',
    // Brights
    '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#0000ff', '#9900ff',
    // Lightest
    '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#cfe2f3', '#d9d2e9',
    // Light
    '#ea9999', '#f9cb9c', '#ffe599', '#b6d7a8', '#a2c4c9', '#9fc5e8', '#b4a7d6',
    // Medium-Light
    '#e06666', '#f6b26b', '#ffd966', '#93c47d', '#76a5af', '#6fa8dc', '#8e7cc3',
    // Medium
    '#cc0000', '#e69138', '#f1c232', '#6aa84f', '#45818e', '#3d85c6', '#674ea7',
    // Dark
    '#990000', '#b45f06', '#bf9000', '#38761d', '#134f5c', '#0b5394', '#351c75',
    // Darkest
    '#660000', '#783f04', '#7f6000', '#274e13', '#0c343d', '#073763', '#20124d'
  ];

  const [attachments, setAttachments] = useState({
    originalPdf: false,
    trafficPhoto: false,
    geotabReport: false
  });

  const toggleAttachment = (key: keyof typeof attachments) => {
    setAttachments(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const editor = useEditor({
    extensions: [
      StarterKit,
      TextStyle,
      Color,
      Underline,
      TextAlign.configure({ types: ['heading', 'paragraph'] })
    ],
    content: messageText,
    onUpdate: ({ editor }) => {
      setMessageText(editor.getHTML());
    },
    editorProps: {
      attributes: {
        class: 'w-full min-h-[120px] p-4 focus:outline-none text-slate-900 dark:text-slate-100 prose dark:prose-invert max-w-none prose-p:my-0 prose-ul:my-1 prose-ol:my-1 prose-li:my-0 ![&_strong]:text-inherit ![&_em]:text-inherit',
      },
      handleKeyDown: (view, event) => {
        if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
          event.preventDefault();
          handleSendMessage();
          return true;
        }
        return false;
      }
    },
  });

  const handleSendMessage = () => {
    if (!editor || editor.isEmpty) return;

    const newMessage: CommunicationMessage = {
      id: Date.now(),
      type: activeChannel,
      text: messageText,
      date: new Date().toLocaleString('en-AU', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      sender: 'Jenny'
    };

    setMessageHistory([...messageHistory, newMessage]);
    setMessageText('');
    editor?.commands.setContent('');
    toast.success(`${activeChannel.toUpperCase()} message sent`);
  };

  function handleDraftWithGemini() {
    // Simulating an API call to Gemini 1.5 Pro
    const promptContext = `Drafting email for ${infringement.vrn} regarding a ${infringement.offence_type} fine. Assigned to: ${infringement.assigned_driver || 'Unknown'}.`;

    const aiDraft = `Hi Team,

I'm reviewing a ${infringement.offence_type} infringement (Ref: ${infringement.reference_number || 'N/A'}) that occurred on ${formatAppDate(infringement.date_received)} involving vehicle ${infringement.vrn}.

Our system indicates ${infringement.assigned_driver || 'a team member'} had the vehicle during this time. Could you please review and process the driver nomination so we can close this out with ${infringement.issuing_authority || 'the authority'}?

Thanks,
Jenny`;

    setMessageText(aiDraft);
    editor?.commands.setContent(aiDraft.replace(/\n/g, '<br>'));
    toast.success('Draft generated by Gemini');
  }

  const handleApplyTemplate = (type: 'nomination' | 'reminder') => {
    let text = '';
    if (type === 'nomination') {
      text = `Dear Fleet Manager,\n\nWe are writing to request driver nomination details for the following traffic infringement:\n\nNotice Number: ${infringement.reference_number || 'N/A'}\nVehicle: ${infringement.vrn}\nOffence Date: ${formatAppDate(infringement.date_received)}\n\nPlease provide the driver details at your earliest convenience.\n\nBest regards,\nCompliance Team`;
    } else if (type === 'reminder') {
      text = `URGENT: Outstanding Infringement ${infringement.reference_number || 'N/A'}\n\nPlease note that the infringement for vehicle ${infringement.vrn} is approaching its due date. Please nominate the driver or process payment immediately to avoid late fees.`;
    }
    setMessageText(text);
    editor?.commands.setContent(text.replace(/\n/g, '<br>'));
    setIsTemplateMenuOpen(false);
  };

  const generateEmailPreview = () => {
    let preview = `Dear Fleet Manager,\n\nWe are writing to request driver nomination details for the following traffic infringement:\n\nNotice Number: ${infringement?.reference_number || 'N/A'}\nVehicle: ${infringement?.vrn || 'N/A'}\nOffence Date: ${infringement?.offence_date ? formatAppDate(infringement.offence_date) : 'N/A'}\nLocation: ${infringement?.offence_location || 'N/A'}\n\n`;

    if (attachments.originalPdf) {
      preview += `I have attached the original infringement notice PDF for your review.\n\n`;
    }
    if (attachments.trafficPhoto) {
      preview += `I have attached the traffic camera photograph showing the vehicle at the time of the offence.\n\n`;
    }
    if (attachments.geotabReport) {
      preview += `I have also attached the Geotab telemetry log confirming the vehicle's speed and location for your reference.\n\n`;
    }

    preview += `Please provide the driver details at your earliest convenience.\n\nBest regards,\nCompliance Team`;
    return preview;
  };

  function calculateDueDate(dateReceived: string): Date {
    const received = new Date(dateReceived);
    const dueDate = new Date(received);
    dueDate.setDate(received.getDate() + 21);
    return dueDate;
  }

  function getDaysUntilDue(dueDate: Date): number {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    const diffTime = due.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  function getUrgencyBadge(daysUntilDue: number) {
    if (daysUntilDue < 0) {
      return {
        text: 'Overdue',
        icon: AlertCircle,
        className: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-400/30'
      };
    } else if (daysUntilDue <= 5) {
      return {
        text: 'Due Soon',
        icon: AlertTriangle,
        className: 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-400/30'
      };
    } else {
      return {
        text: 'Safe',
        icon: CheckCircle2,
        className: 'bg-slate-100 text-slate-500 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
      };
    }
  }

  function getStatusColor(status: string) {
    const colors: Record<string, string> = {
      'New': 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700',
      'Awaiting Driver Nomination': 'bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700',
      'Pending Driver Nomination': 'bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700',
      'Stat Dec Pending': 'bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700',
      'Pending Fleet Payment': 'bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-700',
      'Awaiting Reimbursement (Xero)': 'bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-300 dark:border-indigo-700',
      'Closed': 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700',
    };
    return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700';
  }

  async function handleSubmitNomination() {
    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('infringements')
        .update({
          status: 'Stat Dec Pending',
          updated_at: new Date().toISOString()
        })
        .eq('id', infringement?.id);

      if (error) throw error;

      await supabase
        .from('audit_logs')
        .insert({
          infringement_id: infringement?.id,
          timestamp: new Date().toISOString(),
          actor: 'System User',
          actor_type: 'user',
          ip_address: '127.0.0.1',
          action: 'Submitted statutory declaration to issuing authority'
        });

      if (onUpdate && infringement) {
        onUpdate({
          ...infringement,
          status: 'Stat Dec Pending',
          updated_at: new Date().toISOString()
        });
      }

      toast.success('Nomination submitted successfully');
      onClose();
    } catch (error) {
      console.error('Error submitting nomination:', error);
      toast.error('Failed to submit nomination');
    } finally {
      setIsSubmitting(false);
    }
  }

  const dueDate = calculateDueDate(infringement?.date_received || new Date().toISOString());
  const daysUntil = getDaysUntilDue(dueDate);
  const urgency = getUrgencyBadge(daysUntil);
  const UrgencyIcon = urgency.icon;

  // Reset verification state when infringement changes
  useEffect(() => {
    setIsVerified(false);
  }, [infringement?.id]);

  async function handleApproveAIMatch() {
    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('infringements')
        .update({
          status: 'Pending Driver Nomination',
          updated_at: new Date().toISOString()
        })
        .eq('id', infringement?.id);

      if (error) throw error;

      await supabase
        .from('audit_logs')
        .insert({
          infringement_id: infringement?.id,
          timestamp: new Date().toISOString(),
          actor: 'System User',
          actor_type: 'user',
          ip_address: '127.0.0.1',
          action: `Approved AI driver match: ${infringement?.assigned_driver}`
        });

      if (onUpdate && infringement) {
        onUpdate({
          ...infringement,
          status: 'Pending Driver Nomination',
          updated_at: new Date().toISOString()
        });
      }

      setIsVerified(true);
      toast.success('Driver match verified');
    } catch (error) {
      console.error('Error approving AI match:', error);
      toast.error('Failed to approve AI match');
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleRejectAIMatch() {
    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('infringements')
        .update({
          assigned_driver: null,
          updated_at: new Date().toISOString()
        })
        .eq('id', infringement?.id);

      if (error) throw error;

      await supabase
        .from('audit_logs')
        .insert({
          infringement_id: infringement?.id,
          timestamp: new Date().toISOString(),
          actor: 'System User',
          actor_type: 'user',
          ip_address: '127.0.0.1',
          action: 'Rejected AI driver match - reassigning required'
        });

      if (onUpdate && infringement) {
        onUpdate({
          ...infringement,
          assigned_driver: null,
          updated_at: new Date().toISOString()
        });
      }

      toast.success('AI match rejected - ready for manual reassignment');
    } catch (error) {
      console.error('Error rejecting AI match:', error);
      toast.error('Failed to reject AI match');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: '.prose strong, .prose b, .prose em, .prose i { color: inherit !important; }' }} />
      {/* Backdrop overlay */}
      <div
        className={`fixed inset-0 z-40 bg-slate-900/20 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Drawer panel */}
      <div className={`fixed top-0 right-0 h-screen w-[600px] sm:w-[800px] z-50 transform transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      } bg-white dark:bg-slate-900 shadow-2xl flex flex-col`}>
        {/* Sticky Entity Header */}
        <div className="sticky top-0 z-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-6 py-3">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <span className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {infringement?.fine_amount != null ? formatCurrency(Number(infringement.fine_amount)) : 'Amount TBC'}
                </span>
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold border ${urgency.className}`}>
                  <UrgencyIcon size={12} />
                  {urgency.text}
                </span>
              </div>
              <p className="text-base font-semibold text-slate-700 dark:text-slate-300 mb-0.5">
                {infringement?.offence_type || 'N/A'}
              </p>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Ref: {infringement?.reference_number || '—'} • ID: {infringement?.internal_id || '—'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`inline-flex items-center px-3 py-1 rounded-full text-sm border ${getStatusColor(infringement?.status || 'New')} font-medium`}
            >
              {infringement?.status || 'New'}
            </span>
          </div>
        </div>

        {/* AI Confidence Card - Compact Horizontal Banner with Verified State */}
        {infringement?.assigned_driver && infringement?.status !== 'Closed' && (
          <>
            {!isVerified ? (
              // State 1: Pending Verification (Purple Banner)
              <div className="bg-purple-50 dark:bg-purple-900/10 px-4 py-3 border border-purple-200 dark:border-purple-800/50 shadow-sm my-3">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  {/* Left Side: Icon + Title + Explanation */}
                  <div className="flex items-start gap-3 flex-1">
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Sparkles size={16} className="text-white" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-purple-800 dark:text-purple-300">
                        AI Match (98%): <span className="font-bold text-purple-950 dark:text-purple-200">{infringement?.assigned_driver}</span>
                      </h3>
                      <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed mt-0.5">
                        Cross-referenced timestamp with Fleetio GPS and booking logs. Vehicle <span className="font-semibold text-slate-900 dark:text-slate-100">{infringement?.vrn}</span> was checked out to this driver during the time of the offence.
                      </p>
                    </div>
                  </div>

                  {/* Right Side: Action Buttons */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={handleApproveAIMatch}
                      disabled={isSubmitting}
                      className="px-3 py-1.5 text-sm bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 dark:from-green-500 dark:to-emerald-500 dark:hover:from-green-600 dark:hover:to-emerald-600 text-white font-bold rounded-lg transition-all shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
                    >
                      <CheckCircle size={14} />
                      Approve
                    </button>
                    <button
                      onClick={handleRejectAIMatch}
                      disabled={isSubmitting}
                      className="px-3 py-1.5 text-sm bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border-2 border-red-300 dark:border-red-600 text-red-700 dark:text-red-400 font-bold rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
                    >
                      <XCircle size={14} />
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              // State 2: Verified (Compact Green Banner)
              <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between px-4 py-2 rounded-lg my-3">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5">
                    <Sparkles size={14} className="text-purple-600 dark:text-purple-400" />
                    <CheckCircle2 size={16} className="text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <span className="text-sm font-medium text-emerald-900 dark:text-emerald-300">
                    AI Match Verified: {infringement?.assigned_driver}
                  </span>
                </div>
                <button
                  onClick={() => {
                    setIsVerified(false);
                    toast.success('Verification undone');
                  }}
                  className="text-xs text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 underline cursor-pointer"
                >
                  Undo
                </button>
              </div>
            )}
          </>
        )}

        {/* Dynamic Navigation Tabs */}
        <div className="border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900">
          <div className="flex px-6 gap-6 overflow-x-auto hide-scrollbar">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-4 py-3 text-sm font-semibold border-b-2 transition-all whitespace-nowrap ${
                activeTab === 'overview'
                  ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <Eye size={16} />
                Overview
              </div>
            </button>
            <button
              onClick={() => setActiveTab('telematics')}
              className={`px-4 py-3 text-sm font-semibold border-b-2 transition-all whitespace-nowrap ${
                activeTab === 'telematics'
                  ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <Radio size={16} />
                Telematics
              </div>
            </button>
            <button
              onClick={() => setActiveTab('communications')}
              className={`px-4 py-3 text-sm font-semibold border-b-2 transition-all whitespace-nowrap ${
                activeTab === 'communications'
                  ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <Mail size={16} />
                Messages
              </div>
            </button>
            <button
              onClick={() => setActiveTab('financials')}
              className={`px-4 py-3 text-sm font-semibold border-b-2 transition-all whitespace-nowrap ${
                activeTab === 'financials'
                  ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <DollarSign size={16} />
                Finance
              </div>
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`px-4 py-3 text-sm font-semibold border-b-2 transition-all whitespace-nowrap ${
                activeTab === 'documents'
                  ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <FileText size={16} />
                Documents
              </div>
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    VRN/Rego
                  </label>
                  <p className="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">
                    {infringement?.vrn || 'N/A'}
                  </p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Customer Base
                  </label>
                  <p className="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">
                    {infringement?.customer_base || 'N/A'}
                  </p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Issue Date
                  </label>
                  <p className="mt-1 text-base font-medium text-slate-700 dark:text-slate-300">
                    {infringement?.offence_date ? formatAppDate(infringement.offence_date) : 'N/A'}
                  </p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Due Date
                  </label>
                  <p className="mt-1 text-base font-medium text-slate-700 dark:text-slate-300">
                    {formatAppDate(dueDate.toISOString())}
                  </p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Issuing Authority
                  </label>
                  <p className="mt-1 text-base font-medium text-slate-700 dark:text-slate-300">
                    {infringement?.issuing_authority || '—'}
                  </p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Issuing State
                  </label>
                  <p className="mt-1 text-base font-medium text-slate-700 dark:text-slate-300">
                    {infringement?.issuing_state || '—'}
                  </p>
                </div>
                <div className="col-span-2">
                  <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Assigned Driver
                  </label>
                  <p className="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">
                    {infringement?.assigned_driver || 'Not assigned'}
                  </p>
                </div>
                {infringement?.offence_location && (
                  <div className="col-span-2">
                    <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      Offence Location
                    </label>
                    <p className="mt-1 text-base font-medium text-slate-700 dark:text-slate-300">
                      {infringement?.offence_location}
                    </p>
                  </div>
                )}
                {infringement?.notes && (
                  <div className="col-span-2">
                    <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      Notes
                    </label>
                    <p className="mt-1 text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 p-3 rounded-lg">
                      {infringement?.notes}
                    </p>
                  </div>
                )}
              </div>

            </div>
          )}

          {activeTab === 'telematics' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-slate-100 to-slate-50 dark:from-slate-800 dark:to-slate-900 rounded-lg p-6 border border-slate-200 dark:border-slate-700">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Radio size={18} className="text-blue-600 dark:text-blue-400" />
                  Geotab Trip Replay
                </h3>
                <div className="bg-white dark:bg-slate-950 rounded-lg h-80 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-600 relative overflow-hidden">
                  <div className="absolute inset-0 bg-slate-200 dark:bg-slate-800">
                    <div className="absolute top-4 left-4 bg-white dark:bg-slate-900 px-3 py-2 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700">
                      <div className="flex items-center gap-2">
                        <Navigation size={16} className="text-blue-600 dark:text-blue-400" />
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          {infringement?.offence_location || 'Location unavailable'}
                        </p>
                      </div>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse shadow-lg"></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                      <Zap size={20} className="text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        NFC Driver ID
                      </p>
                      <p className="text-lg font-bold text-slate-900 dark:text-slate-100">
                        {infringement?.assigned_driver || 'Unknown'}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Verified via Geotab NFC tag scan at trip start
                  </p>
                </div>

                <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
                      <TrendingUp size={20} className="text-red-600 dark:text-red-400" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Speed Data
                      </p>
                      <p className="text-lg font-bold text-slate-900 dark:text-slate-100">
                        68 km/h in 60 zone
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Recorded speed vs posted limit at offence time
                  </p>
                </div>
              </div>

              <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-3 mb-3">
                  <Camera size={20} className="text-slate-600 dark:text-slate-400" />
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    Traffic Camera Evidence
                  </h4>
                </div>
                <div className="bg-slate-100 dark:bg-slate-900 rounded-lg h-48 flex items-center justify-center border border-slate-200 dark:border-slate-700">
                  <div className="text-center">
                    <Camera size={48} className="mx-auto text-slate-400 dark:text-slate-500 mb-2" />
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
                      Camera Photo Available
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                      VRN {infringement?.vrn} captured
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'communications' && (
            <div className="space-y-4 flex flex-col h-full">
              {/* Chat Timeline */}
              <div className="overflow-y-auto max-h-[400px] mb-4 p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700">
                <div className="flex flex-col gap-4">
                  {messageHistory.map((message) => (
                    <div key={message.id} className="flex justify-end">
                      <div className="max-w-[80%] bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 p-3 shadow-sm">
                        <div className="flex items-center gap-2 mb-2">
                          {message.type === 'email' ? (
                            <Mail size={14} className="text-blue-600 dark:text-blue-400" />
                          ) : message.type === 'sms' ? (
                            <Smartphone size={14} className="text-purple-600 dark:text-purple-400" />
                          ) : (
                            <MessagesSquare size={14} className="text-emerald-600 dark:text-emerald-400" />
                          )}
                          <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                            {message.sender}
                          </span>
                          <span className="text-xs text-slate-500 dark:text-slate-400">
                            {message.date}
                          </span>
                        </div>
                        <div dangerouslySetInnerHTML={{ __html: message.text }} className="prose prose-sm dark:prose-invert max-w-none prose-p:my-0 prose-ul:my-0.5 prose-ol:my-0.5 prose-li:my-0 ![&_strong]:text-inherit ![&_em]:text-inherit" />
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Omnichannel Composer */}
              <div className="bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                {/* Channel Tabs */}
                <div className="flex gap-2 mb-4">
                  <button
                    onClick={() => setActiveChannel('email')}
                    className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                      activeChannel === 'email'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Mail size={14} />
                      Email
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveChannel('sms')}
                    className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                      activeChannel === 'sms'
                        ? 'bg-purple-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Smartphone size={14} />
                      SMS
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveChannel('whatsapp')}
                    className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                      activeChannel === 'whatsapp'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <MessagesSquare size={16} />
                      WhatsApp
                    </div>
                  </button>
                </div>

                {/* Input Area */}
                {/* Unified Composer Card */}
                <div className="flex flex-col border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-white dark:bg-slate-900 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all">
                  {/* Formatting Toolbar */}
                  <div className="flex flex-wrap items-center gap-1 px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700">
                    <button onClick={() => editor?.chain().focus().undo().run()} disabled={!editor?.can().undo()} className="p-1.5 text-slate-500 hover:text-slate-700 disabled:opacity-50"><Undo size={16} /></button>
                    <button onClick={() => editor?.chain().focus().redo().run()} disabled={!editor?.can().redo()} className="p-1.5 text-slate-500 hover:text-slate-700 disabled:opacity-50"><Redo size={16} /></button>

                    <div className="w-px h-4 bg-slate-300 dark:bg-slate-600 mx-1"></div>

                    <button onClick={() => editor?.chain().focus().toggleBold().run()} className={`p-1.5 rounded ${editor?.isActive('bold') ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><Bold size={16} /></button>
                    <button onClick={() => editor?.chain().focus().toggleItalic().run()} className={`p-1.5 rounded ${editor?.isActive('italic') ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><Italic size={16} /></button>
                    <button onClick={() => editor?.chain().focus().toggleUnderline().run()} className={`p-1.5 rounded ${editor?.isActive('underline') ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><UnderlineIcon size={16} /></button>

                    <div className="relative">
                      <button onClick={() => setIsColorMenuOpen(!isColorMenuOpen)} className="flex items-center justify-center gap-1 p-1.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700">
                        <Type size={16} style={{ color: editor?.getAttributes('textStyle').color || 'inherit' }} />
                        <ChevronDown size={12} className="text-slate-500" />
                      </button>
                      {isColorMenuOpen && (
                        <div className="absolute top-full left-0 mt-1 p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded shadow-xl z-50 w-max">
                          <div className="grid grid-cols-7 gap-0.5">
                            {GMAIL_COLORS.map(color => (
                              <button
                                key={color}
                                type="button"
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => { editor?.chain().focus().setColor(color).run(); setIsColorMenuOpen(false); }}
                                className="w-5 h-5 rounded-sm border border-transparent hover:border-slate-400 dark:hover:border-slate-500 hover:scale-110 transition-all"
                                style={{ backgroundColor: color }}
                                title={color}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="w-px h-4 bg-slate-300 dark:bg-slate-600 mx-1"></div>

                    <button onClick={() => editor?.chain().focus().setTextAlign('left').run()} className={`p-1.5 rounded ${editor?.isActive({ textAlign: 'left' }) ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><AlignLeft size={16} /></button>
                    <button onClick={() => editor?.chain().focus().setTextAlign('center').run()} className={`p-1.5 rounded ${editor?.isActive({ textAlign: 'center' }) ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><AlignCenter size={16} /></button>
                    <button onClick={() => editor?.chain().focus().setTextAlign('right').run()} className={`p-1.5 rounded ${editor?.isActive({ textAlign: 'right' }) ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><AlignRight size={16} /></button>

                    <div className="w-px h-4 bg-slate-300 dark:bg-slate-600 mx-1"></div>

                    <button onClick={() => editor?.chain().focus().toggleOrderedList().run()} className={`p-1.5 rounded ${editor?.isActive('orderedList') ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><ListOrdered size={16} /></button>
                    <button onClick={() => editor?.chain().focus().toggleBulletList().run()} className={`p-1.5 rounded ${editor?.isActive('bulletList') ? 'bg-slate-200 dark:bg-slate-600' : 'hover:bg-slate-100'}`}><List size={16} /></button>
                  </div>

                  {/* Editor */}
                  <EditorContent editor={editor} />

                  {/* Action Bar */}
                  <div className="flex items-center justify-between px-3 py-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <button
                        onClick={() => setIsTemplateMenuOpen(!isTemplateMenuOpen)}
                        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      >
                        <Wand2 size={16} />
                        Templates
                      </button>
                      {isTemplateMenuOpen && (
                        <div className="absolute bottom-full left-0 mb-2 w-56 bg-white dark:bg-slate-800 rounded-lg shadow-xl border border-slate-200 dark:border-slate-700 overflow-hidden z-50">
                          <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-700">
                            Insert Template
                          </div>
                          <button
                            onClick={() => handleApplyTemplate('nomination')}
                            className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors border-b border-slate-100 dark:border-slate-700"
                          >
                            Driver Nomination Request
                          </button>
                          <button
                            onClick={() => handleApplyTemplate('reminder')}
                            className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                          >
                            Urgent Payment Reminder
                          </button>
                        </div>
                      )}
                    </div>

                    {/* New Gemini Button */}
                    <button
                      onClick={handleDraftWithGemini}
                      className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 dark:border-purple-800/50 rounded-lg dark:text-purple-300 dark:bg-purple-900/20 dark:hover:bg-purple-900/40 transition-colors"
                    >
                      <Sparkles size={16} />
                      <span className="hidden sm:inline">Draft with Gemini</span>
                    </button>
                  </div>
                  <button
                    onClick={handleSendMessage}
                    disabled={!editor || editor.isEmpty}
                    className={`flex items-center gap-2 px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors ${!editor || editor.isEmpty ? 'bg-slate-300 dark:bg-slate-700 text-slate-500 cursor-not-allowed' : activeChannel === 'email' ? 'bg-blue-600 hover:bg-blue-700 shadow-sm' : activeChannel === 'sms' ? 'bg-purple-600 hover:bg-purple-700 shadow-sm' : 'bg-emerald-600 hover:bg-emerald-700 shadow-sm'}`}
                  >
                    <Send size={16} />
                    Send Message
                  </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'financials' && (
            <div className="space-y-6">
              {/* Xero-style Create Bill Card */}
              <div className="bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 overflow-hidden">
                {/* Header */}
                <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/10 dark:to-cyan-900/10">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-600 dark:bg-blue-500 rounded flex items-center justify-center">
                      <span className="text-white font-bold text-sm">X</span>
                    </div>
                    <h3 className="text-base font-bold text-blue-900 dark:text-blue-100">
                      Create Bill in Xero
                    </h3>
                  </div>
                </div>

                {/* Who/What/Why Inputs */}
                <div className="px-6 py-5 space-y-4">
                  {/* Row 1: Who */}
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <label className="col-span-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                      Who
                    </label>
                    <div className="col-span-10">
                      <input
                        type="text"
                        value={infringement?.issuing_authority || ''}
                        readOnly
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                      />
                    </div>
                  </div>

                  {/* Row 2: What */}
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <label className="col-span-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                      What
                    </label>
                    <div className="col-span-10">
                      <select
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                      >
                        <option>429 - General Expenses</option>
                        <option>200 - Sales</option>
                        <option>400 - Advertising</option>
                        <option>410 - Bank Fees</option>
                      </select>
                    </div>
                  </div>

                  {/* Row 3: Why */}
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <label className="col-span-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                      Why
                    </label>
                    <div className="col-span-10">
                      <input
                        type="text"
                        value={`Infringement ${infringement?.reference_number || 'N/A'} - ${infringement?.vrn || 'N/A'}`}
                        readOnly
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                      />
                    </div>
                  </div>
                </div>

                {/* Line Item Grid */}
                <div className="px-6 pb-5">
                  <div className="bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700 p-4">
                    <div className="grid grid-cols-12 gap-4 items-center">
                      <div className="col-span-4">
                        <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          Tracking Category
                        </label>
                        <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mt-1">
                          {infringement?.customer_base || 'N/A'}
                        </p>
                      </div>
                      <div className="col-span-4">
                        <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          Tax Rate
                        </label>
                        <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mt-1">
                          BAS Excluded
                        </p>
                      </div>
                      <div className="col-span-4 text-right">
                        <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          Amount
                        </label>
                        <p className="text-lg font-bold text-slate-900 dark:text-slate-100 mt-1">
                          {infringement?.fine_amount != null ? formatCurrency(Number(infringement.fine_amount)) : '$0.00'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Button */}
                <div className="px-6 pb-6 flex justify-end">
                  <button className="px-8 py-3 bg-[#10a852] hover:bg-[#0e9247] text-white font-semibold rounded-md transition-colors shadow-sm hover:shadow-md flex items-center gap-2">
                    <DollarSign size={18} />
                    Push to Xero
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <FileText size={18} className="text-blue-600 dark:text-blue-400" />
                  Source Documents
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                  Original notices and supporting documentation from government authorities and internal systems.
                </p>
              </div>

              <div className="space-y-3">
                {/* Document 1 */}
                <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-10 h-10 bg-red-100 dark:bg-red-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText size={20} className="text-red-600 dark:text-red-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                        Original Infringement Notice.pdf
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Uploaded {infringement?.date_received ? formatAppDate(infringement.date_received) : 'N/A'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => toast.info('Document preview coming soon')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Preview"
                    >
                      <Eye size={18} />
                    </button>
                    <button
                      onClick={() => toast.success('Downloading document...')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Download"
                    >
                      <Download size={18} />
                    </button>
                    <button
                      onClick={() => toast.success('Email sent with document attached')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Email Document"
                    >
                      <Mail size={18} />
                    </button>
                  </div>
                </div>

                {/* Document 2 */}
                <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText size={20} className="text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                        Geotab_Audit_Log.pdf
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Generated {infringement?.date_received ? formatAppDate(new Date(new Date(infringement.date_received).getTime() + 86400000).toISOString()) : 'N/A'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => toast.info('Document preview coming soon')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Preview"
                    >
                      <Eye size={18} />
                    </button>
                    <button
                      onClick={() => toast.success('Downloading document...')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Download"
                    >
                      <Download size={18} />
                    </button>
                    <button
                      onClick={() => toast.success('Email sent with document attached')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Email Document"
                    >
                      <Mail size={18} />
                    </button>
                  </div>
                </div>

                {/* Document 3 */}
                <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText size={20} className="text-amber-600 dark:text-amber-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                        Overdue Reminder Notice.pdf
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Received {infringement?.date_received ? formatAppDate(new Date(new Date(infringement.date_received).getTime() + 1296000000).toISOString()) : 'N/A'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => toast.info('Document preview coming soon')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Preview"
                    >
                      <Eye size={18} />
                    </button>
                    <button
                      onClick={() => toast.success('Downloading document...')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Download"
                    >
                      <Download size={18} />
                    </button>
                    <button
                      onClick={() => toast.success('Email sent with document attached')}
                      className="p-2 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      title="Email Document"
                    >
                      <Mail size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ocr' && (
            <div className="space-y-6">
              <div className="bg-slate-100 dark:bg-slate-800 rounded-lg h-64 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-600">
                <div className="text-center">
                  <FileText size={48} className="mx-auto text-slate-400 dark:text-slate-500 mb-3" />
                  <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
                    Scanned PDF Document
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                    Document preview placeholder
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Extracted Fields
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                        VRN Match
                      </span>
                    </div>
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                      99%
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                        Reference Number
                      </span>
                    </div>
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                      98%
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                        Fine Amount
                      </span>
                    </div>
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                      97%
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                        Offence Date
                      </span>
                    </div>
                    <span className="text-sm font-semibold text-amber-600 dark:text-amber-400">
                      89%
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                        Issuing Authority
                      </span>
                    </div>
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                      95%
                    </span>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 size={16} className="text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-semibold text-blue-900 dark:text-blue-300">
                        OCR Verification Complete
                      </p>
                      <p className="text-xs text-blue-700 dark:text-blue-400 mt-0.5">
                        {infringement.ocr_verified_by || 'System'} verified on {infringement.ocr_verified_at ? formatAppDate(infringement.ocr_verified_at) : 'N/A'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="space-y-4">
              {loadingAudit ? (
                <div className="flex items-center justify-center h-32">
                  <p className="text-sm text-slate-500 dark:text-slate-400">Loading audit trail...</p>
                </div>
              ) : auditLogs.length === 0 ? (
                <div className="flex items-center justify-center h-32">
                  <p className="text-sm text-slate-500 dark:text-slate-400">No audit events found</p>
                </div>
              ) : (
                <div className="relative">
                  <div className="absolute left-[11px] top-0 bottom-0 w-0.5 bg-slate-200 dark:bg-slate-700"></div>
                  <div className="space-y-4">
                    {auditLogs.map((log, index) => (
                      <div key={log.id} className="relative pl-8">
                        <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-white dark:bg-slate-900 border-2 border-blue-600 dark:border-blue-400 flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full bg-blue-600 dark:bg-blue-400"></div>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4 border border-slate-200 dark:border-slate-700">
                          <div className="flex items-start justify-between mb-1">
                            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                              {log.action}
                            </p>
                            <span className="text-xs text-slate-500 dark:text-slate-400">
                              {formatAppDate(log.timestamp)}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                            by {log.actor} ({log.actor_type})
                          </p>
                          {log.ip_address && (
                            <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                              IP: {log.ip_address}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Footer */}
        {showSignaturePad ? (
          <div className="border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-6">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4 flex items-center gap-2">
              <PenTool size={18} className="text-blue-600 dark:text-blue-400" />
              Electronic Signature
            </h3>
            <div className="bg-slate-50 dark:bg-slate-800 rounded-lg h-40 border-2 border-dashed border-slate-300 dark:border-slate-600 flex items-center justify-center mb-4">
              <p className="text-sm text-slate-500 dark:text-slate-400">Signature pad placeholder</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowSignaturePad(false)}
                className="px-6 py-3 border-2 border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 font-semibold rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitNomination}
                disabled={isSubmitting}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-semibold rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>Processing...</>
                ) : (
                  <>
                    <CheckCircle2 size={18} />
                    Confirm & Submit
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-4">
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => toast.info('Undo functionality coming soon')}
                className="px-4 py-3 flex items-center justify-center gap-2 border-2 border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-400 font-semibold rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <Undo2 size={18} />
                Undo Last Step
              </button>
              <button
                onClick={() => setShowSignaturePad(true)}
                className="px-4 py-3 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-semibold rounded-lg transition-colors shadow-sm"
              >
                <PenTool size={18} />
                Review & Sign Stat Dec
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
