import { useState, useEffect } from 'react';
import { X, FileCheck } from 'lucide-react';
import type { StatutoryDeclarationPayload } from '../types/database';
import { formatAppDate } from '../utils/formatters';

interface DriverData {
  driver_name: string;
  method: string;
}

interface StatDecModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: StatutoryDeclarationPayload) => void;
  infringementNoticeNumber: string;
  vehicleRegistration: string;
  offenceDate: string;
  driverData?: DriverData;
  brandName?: string;
}

export function StatDecModal({
  isOpen,
  onClose,
  onSubmit,
  infringementNoticeNumber,
  vehicleRegistration,
  offenceDate,
  driverData,
  brandName = 'Fleetcar',
}: StatDecModalProps) {
  const getDefaultDriverData = () => {
    if (!driverData?.driver_name) {
      return {
        nominated_driver_name: '',
        nominated_driver_address: '',
        nominated_driver_license_number: '',
        nominated_driver_license_state: 'QLD',
        nominated_driver_dob: '',
      };
    }

    return {
      nominated_driver_name: driverData.driver_name,
      nominated_driver_address: '123 Fake Street, Sydney NSW 2000',
      nominated_driver_license_number: 'NSW-8839201',
      nominated_driver_license_state: 'NSW',
      nominated_driver_dob: '1985-06-15',
    };
  };

  const getCompanyName = () => {
    if (brandName === 'GigCar') return 'GigCar Pty Ltd';
    if (brandName === 'Yonder') return 'Yonder Pty Ltd';
    return 'Fleetcar Pty Ltd';
  };

  const [formData, setFormData] = useState<StatutoryDeclarationPayload>({
    infringement_notice_number: infringementNoticeNumber,
    vehicle_registration: vehicleRegistration,
    offence_date: offenceDate,
    company_name: getCompanyName(),
    declarant_name: 'Jenny Thompson',
    ...getDefaultDriverData(),
  });

  useEffect(() => {
    if (isOpen) {
      setFormData({
        infringement_notice_number: infringementNoticeNumber,
        vehicle_registration: vehicleRegistration,
        offence_date: offenceDate,
        company_name: getCompanyName(),
        declarant_name: 'Jenny Thompson',
        ...getDefaultDriverData(),
      });
    }
  }, [isOpen, driverData, infringementNoticeNumber, vehicleRegistration, offenceDate, brandName]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field: keyof StatutoryDeclarationPayload, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-[95%] md:max-w-3xl max-h-[90vh] overflow-y-auto flex flex-col">
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <FileCheck size={20} className="text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-slate-900">
                Generate Statutory Declaration
              </h2>
              <p className="text-sm text-slate-600">Driver Nomination Form</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X size={20} className="text-slate-600" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-auto">
          <div className="p-6 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">
                Infringement Details
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Notice Number
                  </label>
                  <input
                    type="text"
                    value={formData.infringement_notice_number}
                    disabled
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Vehicle Registration
                  </label>
                  <input
                    type="text"
                    value={formData.vehicle_registration}
                    disabled
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Offence Date
                  </label>
                  <input
                    type="text"
                    value={formatAppDate(formData.offence_date)}
                    disabled
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-900"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">
                Company Details
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Company Name
                  </label>
                  <input
                    type="text"
                    value={formData.company_name}
                    onChange={(e) => handleChange('company_name', e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Declarant Name
                  </label>
                  <input
                    type="text"
                    value={formData.declarant_name}
                    onChange={(e) => handleChange('declarant_name', e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wide">
                Nominated Driver Details
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nominated_driver_name}
                    onChange={(e) => handleChange('nominated_driver_name', e.target.value)}
                    placeholder="Enter driver's full name"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Residential Address <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={formData.nominated_driver_address}
                    onChange={(e) => handleChange('nominated_driver_address', e.target.value)}
                    placeholder="Enter full residential address"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    License Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nominated_driver_license_number}
                    onChange={(e) =>
                      handleChange('nominated_driver_license_number', e.target.value)
                    }
                    placeholder="e.g., 12345678"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    License State <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    value={formData.nominated_driver_license_state}
                    onChange={(e) =>
                      handleChange('nominated_driver_license_state', e.target.value)
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    <option value="QLD">Queensland</option>
                    <option value="NSW">New South Wales</option>
                    <option value="VIC">Victoria</option>
                    <option value="SA">South Australia</option>
                    <option value="WA">Western Australia</option>
                    <option value="TAS">Tasmania</option>
                    <option value="NT">Northern Territory</option>
                    <option value="ACT">Australian Capital Territory</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Date of Birth <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.nominated_driver_dob}
                    onChange={(e) => handleChange('nominated_driver_dob', e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex gap-3 justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
            >
              <FileCheck size={18} />
              Generate PDF & Mark as Pending
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
