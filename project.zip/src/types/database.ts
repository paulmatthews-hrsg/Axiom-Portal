export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      infringements: {
        Row: {
          id: string
          internal_id: string
          date_received: string
          customer_base: 'GigCar' | 'Fleetcar' | 'Yonder'
          vrn: string
          offence_type: string
          offence_date: string
          offence_location: string | null
          assigned_driver: string | null
          status: 'New' | 'Pending Driver Nomination' | 'Awaiting Driver Nomination' | 'Stat Dec Pending' | 'Awaiting Signature' | 'Ready for Submission' | 'Pending Fleet Payment' | 'Awaiting Reimbursement (Xero)' | 'Closed' | 'Voided'
          fine_amount: number | null
          reference_number: string | null
          notes: string | null
          issuing_state: 'NT' | 'NSW' | 'QLD' | 'VIC' | 'WA' | 'SA' | 'TAS' | 'ACT' | null
          issuing_authority: string | null
          corporate_fine_amount: number | null
          bpay_biller_code: string | null
          bpay_reference: string | null
          reissued_individual_fine_amount: number | null
          ocr_verified: boolean
          ocr_verified_at: string | null
          ocr_verified_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          internal_id?: string
          date_received?: string
          customer_base: 'GigCar' | 'Fleetcar' | 'Yonder'
          vrn: string
          offence_type: string
          offence_date: string
          offence_location?: string | null
          assigned_driver?: string | null
          status?: 'New' | 'Pending Driver Nomination' | 'Awaiting Driver Nomination' | 'Stat Dec Pending' | 'Pending Fleet Payment' | 'Awaiting Reimbursement (Xero)' | 'Closed' | 'Voided'
          fine_amount?: number | null
          reference_number?: string | null
          notes?: string | null
          issuing_state?: 'NT' | 'NSW' | 'QLD' | 'VIC' | 'WA' | 'SA' | 'TAS' | 'ACT' | null
          issuing_authority?: string | null
          corporate_fine_amount?: number | null
          bpay_biller_code?: string | null
          bpay_reference?: string | null
          reissued_individual_fine_amount?: number | null
          ocr_verified?: boolean
          ocr_verified_at?: string | null
          ocr_verified_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          internal_id?: string
          date_received?: string
          customer_base?: 'GigCar' | 'Fleetcar' | 'Yonder'
          vrn?: string
          offence_type?: string
          offence_date?: string
          offence_location?: string | null
          assigned_driver?: string | null
          status?: 'New' | 'Pending Driver Nomination' | 'Awaiting Driver Nomination' | 'Stat Dec Pending' | 'Pending Fleet Payment' | 'Awaiting Reimbursement (Xero)' | 'Closed' | 'Voided'
          fine_amount?: number | null
          reference_number?: string | null
          notes?: string | null
          issuing_state?: 'NT' | 'NSW' | 'QLD' | 'VIC' | 'WA' | 'SA' | 'TAS' | 'ACT' | null
          issuing_authority?: string | null
          corporate_fine_amount?: number | null
          bpay_biller_code?: string | null
          bpay_reference?: string | null
          reissued_individual_fine_amount?: number | null
          ocr_verified?: boolean
          ocr_verified_at?: string | null
          ocr_verified_by?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      activity_logs: {
        Row: {
          id: string
          infringement_id: string
          action_type: string
          action_description: string
          performed_by: string
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          infringement_id: string
          action_type: string
          action_description: string
          performed_by?: string
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          infringement_id?: string
          action_type?: string
          action_description?: string
          performed_by?: string
          metadata?: Json
          created_at?: string
        }
      }
      audit_logs: {
        Row: {
          id: string
          infringement_id: string | null
          timestamp: string
          actor: string
          actor_type: 'user' | 'system'
          ip_address: string
          action: string
          created_at: string
        }
        Insert: {
          id?: string
          infringement_id?: string | null
          timestamp?: string
          actor: string
          actor_type: 'user' | 'system'
          ip_address: string
          action: string
          created_at?: string
        }
        Update: {
          id?: string
          infringement_id?: string | null
          timestamp?: string
          actor?: string
          actor_type?: 'user' | 'system'
          ip_address?: string
          action?: string
          created_at?: string
        }
      }
      vehicles: {
        Row: {
          id: string
          created_at: string
          vehicle_name: string
          vin: string | null
          license_plate: string | null
          year: number | null
          make: string | null
          model: string | null
          status: string | null
          fleetio_id: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          vehicle_name: string
          vin?: string | null
          license_plate?: string | null
          year?: number | null
          make?: string | null
          model?: string | null
          status?: string | null
          fleetio_id?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          vehicle_name?: string
          vin?: string | null
          license_plate?: string | null
          year?: number | null
          make?: string | null
          model?: string | null
          status?: string | null
          fleetio_id?: string | null
        }
      }
      bpa_agreements: {
        Row: {
          id: string
          agreement_number: string
          vendor_name: string
          vendor_category: string
          description: string | null
          total_value: number
          currency: string
          start_date: string
          end_date: string | null
          status: string
          contact_name: string | null
          contact_email: string | null
          contact_phone: string | null
          payment_terms: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          agreement_number?: string
          vendor_name: string
          vendor_category?: string
          description?: string | null
          total_value?: number
          currency?: string
          start_date?: string
          end_date?: string | null
          status?: string
          contact_name?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          payment_terms?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          agreement_number?: string
          vendor_name?: string
          vendor_category?: string
          description?: string | null
          total_value?: number
          currency?: string
          start_date?: string
          end_date?: string | null
          status?: string
          contact_name?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          payment_terms?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}

export type Infringement = Database['public']['Tables']['infringements']['Row'];
export type ActivityLog = Database['public']['Tables']['activity_logs']['Row'];
export type AuditLog = Database['public']['Tables']['audit_logs']['Row'];
export type Vehicle = Database['public']['Tables']['vehicles']['Row'];
export type BpaAgreement = Database['public']['Tables']['bpa_agreements']['Row'];

export interface StatutoryDeclarationPayload {
  infringement_notice_number: string;
  vehicle_registration: string;
  offence_date: string;
  company_name: string;
  declarant_name: string;
  nominated_driver_name: string;
  nominated_driver_address: string;
  nominated_driver_license_number: string;
  nominated_driver_license_state: string;
  nominated_driver_dob: string;
}

export interface XeroReimbursementPayload {
  driver_name: string;
  reissued_individual_fine_amount: number;
  attach_documents: boolean;
}
